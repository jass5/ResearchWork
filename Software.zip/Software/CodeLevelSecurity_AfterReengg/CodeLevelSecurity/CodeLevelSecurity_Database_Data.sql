-- MySQL dump 10.13  Distrib 5.1.37, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: codelevelsecurity
-- ------------------------------------------------------
-- Server version	5.1.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


drop database if exists codelevelsecurity;
create database codelevelsecurity;
use codelevelsecurity;


--
-- Table structure for table `programaccessmaster`
--

DROP TABLE IF EXISTS `programaccessmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programaccessmaster` (
  `Program_Access_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Program_ID` int(11) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Access_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_Access_ID`),
  KEY `fk_ProgramAccessMaster_ProgramMaster` (`Program_ID`),
  KEY `fk_ProgramAccessMaster_UserMaster` (`User_ID`),
  CONSTRAINT `fk_ProgramAccessMaster_ProgramMaster` FOREIGN KEY (`Program_ID`) REFERENCES `programmaster` (`Program_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ProgramAccessMaster_UserMaster` FOREIGN KEY (`User_ID`) REFERENCES `usermaster` (`User_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programaccessmaster`
--

LOCK TABLES `programaccessmaster` WRITE;
/*!40000 ALTER TABLE `programaccessmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `programaccessmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programmaster`
--

DROP TABLE IF EXISTS `programmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programmaster` (
  `Program_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) DEFAULT NULL,
  `Program_Name` varchar(45) DEFAULT NULL,
  `Program_Path` varchar(100) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_ID`),
  KEY `fk_ProgramMaster_UserMaster` (`User_ID`),
  CONSTRAINT `fk_ProgramMaster_UserMaster` FOREIGN KEY (`User_ID`) REFERENCES `usermaster` (`User_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programmaster`
--

LOCK TABLES `programmaster` WRITE;
/*!40000 ALTER TABLE `programmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `programmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programupdatemaster`
--

DROP TABLE IF EXISTS `programupdatemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programupdatemaster` (
  `Program_Update_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Program_ID` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_Update_ID`),
  KEY `fk_ProgramUpdateMaster_ProgramMaster` (`Program_ID`),
  CONSTRAINT `fk_ProgramUpdateMaster_ProgramMaster` FOREIGN KEY (`Program_ID`) REFERENCES `programmaster` (`Program_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programupdatemaster`
--

LOCK TABLES `programupdatemaster` WRITE;
/*!40000 ALTER TABLE `programupdatemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `programupdatemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usermaster`
--

DROP TABLE IF EXISTS `usermaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usermaster` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `User_Type` varchar(20) DEFAULT NULL,
  `User_Status` varchar(20) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Contact_Number` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usermaster`
--

LOCK TABLES `usermaster` WRITE;
/*!40000 ALTER TABLE `usermaster` DISABLE KEYS */;
INSERT INTO `usermaster` VALUES (1,'admin','admin','Administrator','Active','Rohan','01724565654','admin@gmail.com'),(2,'employee','employee','Employee','Active','Aakash','98888989898','employee@gmail.com'),(3,'User','user','Employee','Active','Rajpreet','9899988888','user@gmail.com');
/*!40000 ALTER TABLE `usermaster` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-05-15 10:11:00
