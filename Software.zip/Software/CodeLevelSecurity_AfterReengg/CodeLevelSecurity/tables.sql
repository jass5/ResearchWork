CREATE TABLE `programaccessmaster` (
  `Program_Access_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Program_ID` int(11) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Access_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_Access_ID`),
  KEY `fk_ProgramAccessMaster_ProgramMaster` (`Program_ID`),
  KEY `fk_ProgramAccessMaster_UserMaster` (`User_ID`),
  CONSTRAINT `fk_ProgramAccessMaster_ProgramMaster` FOREIGN KEY (`Program_ID`) REFERENCES `programmaster` (`Program_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ProgramAccessMaster_UserMaster` FOREIGN KEY (`User_ID`) REFERENCES `usermaster` (`User_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `programmaster` (
  `Program_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) DEFAULT NULL,
  `Program_Name` varchar(45) DEFAULT NULL,
  `Program_Path` varchar(100) DEFAULT NULL,
  `Create_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_ID`),
  KEY `fk_ProgramMaster_UserMaster` (`User_ID`),
  CONSTRAINT `fk_ProgramMaster_UserMaster` FOREIGN KEY (`User_ID`) REFERENCES `usermaster` (`User_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `programupdatemaster` (
  `Program_Update_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Program_ID` int(11) DEFAULT NULL,
  `Update_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Program_Update_ID`),
  KEY `fk_ProgramUpdateMaster_ProgramMaster` (`Program_ID`),
  CONSTRAINT `fk_ProgramUpdateMaster_ProgramMaster` FOREIGN KEY (`Program_ID`) REFERENCES `programmaster` (`Program_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `usermaster` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `User_Type` varchar(20) DEFAULT NULL,
  `User_Status` varchar(20) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Contact_Number` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


INSERT INTO `usermaster` VALUES (1,'admin','admin','Administrator','Active','Rohan','01724565654','admin@gmail.com'),(2,'employee','employee','Employee','Active','Aakash','98888989898','employee@gmail.com'),(3,'User','user','Employee','Active','Rajpreet','9899988888','user@gmail.com');