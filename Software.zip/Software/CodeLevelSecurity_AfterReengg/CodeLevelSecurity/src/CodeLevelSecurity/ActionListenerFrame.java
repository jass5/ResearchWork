/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CodeLevelSecurity;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import CodeLevelSecurity.alpha.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ActionListenerFrame extends javax.swing.JFrame implements ActionListener{

    String flag = "";
    public ActionListenerFrame() {
        initComponents();
        txtUsername.setEditable(false);
        txtPassword.setEditable(false);
        ddlUsertype.setEditable(false);
        ddlUserstatus.setEditable(false);
        txtName.setEditable(false);
        txtContactnumber.setEditable(false);
        txtEmail.setEditable(false);
        btnSave.setEnabled(false);
        this.btnPrev.addActionListener(this);
        this.btnNext.addActionListener(this);
        this.btnFirst.addActionListener(this);
        this.btnLast.addActionListener(this);
        this.btnSave.addActionListener(this);
        this.btnCancel.addActionListener(this);
        this.btnAdd.addActionListener(this);
        this.btnUpdate.addActionListener(this);
        getFirst();
    }
    
    public int getMaxId()
    {
        int max=0;
        try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement stmt=con.prepareStatement("select max(User_ID) from usermaster");
            ResultSet rs=stmt.executeQuery();
            while(rs.next())
            {
                max=rs.getInt(1);
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(rootPane, "(AddUsers) GetMaxId = "+e);
        }
        return max;
    }
    
    public void getFirst()
    {
        try
        {
            Connection con = DBConnection.getConnection();
            PreparedStatement stmt=con.prepareStatement("SELECT * FROM usermaster  limit 1");
            ResultSet rs=stmt.executeQuery();
            if(rs.next())
            {
                txtUserid.setText(""+rs.getInt("User_ID")); 
                txtUsername.setText(rs.getString("Username"));
                txtPassword.setText(rs.getString("Password"));
                txtName.setText(rs.getString("Name"));
                txtContactnumber.setText(rs.getString("Contact_Number"));
                txtEmail.setText(rs.getString("Email"));

            }
            con.close();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(rootPane, "showFirstLast(first) : "+ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        txtUserid = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        ddlUsertype = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        ddlUserstatus = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtContactnumber = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnFirst = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnPrev = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("User ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 76, -1));

        txtUserid.setEditable(false);
        getContentPane().add(txtUserid, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 170, -1));

        jLabel9.setFont(new java.awt.Font("DejaVu Sans", 1, 18)); // NOI18N
        jLabel9.setText("User Detail");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, -1, -1));

        jLabel3.setText("Username");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, -1, 31));
        getContentPane().add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 170, -1));

        jLabel4.setText("Password");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 72, 21));
        getContentPane().add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 170, 25));

        jLabel5.setText("User Type");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, -1, -1));

        ddlUsertype.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Administrator", "Employee" }));
        getContentPane().add(ddlUsertype, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 160, 170, -1));

        jLabel6.setText("User Status");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        ddlUserstatus.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Active", "Inactive" }));
        getContentPane().add(ddlUserstatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 170, -1));

        jLabel7.setText("Name");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, -1, -1));
        getContentPane().add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 170, -1));

        jLabel8.setText("Contact Number");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, -1, -1));
        getContentPane().add(txtContactnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, 170, -1));

        jLabel10.setText("Email");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 52, -1));
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 280, 170, -1));

        btnFirst.setText("First");
        getContentPane().add(btnFirst, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, 80, -1));

        btnAdd.setText("Add");
        getContentPane().add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, 80, -1));

        btnUpdate.setText("Update");
        getContentPane().add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 380, 80, -1));

        btnPrev.setText("Prev");
        getContentPane().add(btnPrev, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 340, 80, -1));

        btnNext.setText("Next");
        getContentPane().add(btnNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 340, 80, -1));

        btnSave.setText("Save");
        getContentPane().add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 380, 80, -1));

        btnCancel.setText("Cancel");
        getContentPane().add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 380, 80, -1));

        btnLast.setText("Last");
        getContentPane().add(btnLast, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 340, 80, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ActionListenerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ActionListenerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ActionListenerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ActionListenerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ActionListenerFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox ddlUserstatus;
    private javax.swing.JComboBox ddlUsertype;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtContactnumber;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUserid;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        String btnClicked = e.getActionCommand();
        int id = Integer.parseInt(txtUserid.getText());
        int userid = Integer.parseInt(txtUserid.getText());
        String username = txtUsername.getText();
        String pass = txtPassword.getText();
        String utype = ddlUsertype.getSelectedItem().toString();
        String ustatus = ddlUserstatus.getSelectedItem().toString();
        String name = txtName.getText();
        String contact = txtContactnumber.getText();
        String email = txtEmail.getText();
        switch(btnClicked)
        {
            case "First":
                        try
                        {
                            Connection con = DBConnection.getConnection();
                            PreparedStatement stmt=con.prepareStatement("SELECT * FROM usermaster  limit 1");
                            ResultSet rs=stmt.executeQuery();
                            if(rs.next())
                            {
                                txtUserid.setText(""+rs.getInt("User_ID")); 
                                txtUsername.setText(rs.getString("Username"));
                                txtPassword.setText(rs.getString("Password"));
                                txtName.setText(rs.getString("Name"));
                                txtContactnumber.setText(rs.getString("Contact_Number"));
                                txtEmail.setText(rs.getString("Email"));

                            }
                            con.close();
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(rootPane, "showFirstLast(first) : "+ex);
                        }
                        break;
            case "Last":
                        try
                        {
                            Connection con = DBConnection.getConnection();
                            PreparedStatement stmt=con.prepareStatement("SELECT * FROM usermaster ORDER BY User_ID DESC LIMIT 1");
                            ResultSet rs=stmt.executeQuery();
                            if(rs.next())
                            {
                                txtUserid.setText(""+rs.getInt("User_ID")); 
                                txtUsername.setText(rs.getString("Username"));
                                txtPassword.setText(rs.getString("Password"));
                                txtName.setText(rs.getString("Name"));
                                txtContactnumber.setText(rs.getString("Contact_Number"));
                                txtEmail.setText(rs.getString("Email"));
                            }
                            con.close();
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(rootPane, "showFirstLast(last) : "+e);
                        }
                        break;
            case "Prev":
                        id--;        
                        try
                        {
                            Connection con = DBConnection.getConnection();
                            PreparedStatement stmt=con.prepareStatement("SELECT * FROM usermaster where User_ID=?");
                            stmt.setInt(1,id);
                            ResultSet rs=stmt.executeQuery();
                            if(rs.next())
                            {
                                txtUserid.setText(""+rs.getInt("User_ID")); 
                                txtUsername.setText(rs.getString("Username"));
                                txtPassword.setText(rs.getString("Password"));
                                txtName.setText(rs.getString("Name"));
                                txtContactnumber.setText(rs.getString("Contact_Number"));
                                txtEmail.setText(rs.getString("Email"));
                            }
                            con.close();
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(rootPane, "showFirstLast(last) : "+e);
                        }
                        break;
            case "Next":
                        id++;
                        try
                        {
                            Connection con = DBConnection.getConnection();
                            PreparedStatement stmt=con.prepareStatement("SELECT * FROM usermaster where User_ID=?");
                            stmt.setInt(1,id);
                            ResultSet rs=stmt.executeQuery();
                            if(rs.next())
                            {
                                txtUserid.setText(""+rs.getInt("User_ID")); 
                                txtUsername.setText(rs.getString("Username"));
                                txtPassword.setText(rs.getString("Password"));
                                txtName.setText(rs.getString("Name"));
                                txtContactnumber.setText(rs.getString("Contact_Number"));
                                txtEmail.setText(rs.getString("Email"));
                            }
                            con.close();
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(rootPane, "showFirstLast(last) : "+e);
                        }
                        break;
            case "Add":
                        txtUsername.setText("");
                        txtPassword.setText("");
                        txtName.setText("");
                        txtContactnumber.setText("");
                        txtEmail.setText("");
                        txtUsername.setEditable(true);
                        txtPassword.setEditable(true);
                        ddlUsertype.setEditable(true);
                        ddlUserstatus.setEditable(true);
                        txtName.setEditable(true);
                        txtContactnumber.setEditable(true);
                        txtEmail.setEditable(true); 
                        int i = getMaxId();
                        i++;
                        txtUserid.setText(""+i);
                        flag = "add";
                        btnFirst.setEnabled(false);
                        btnPrev.setEnabled(false);
                        btnNext.setEnabled(false);
                        btnLast.setEnabled(false);
                        btnAdd.setEnabled(false);
                        btnUpdate.setEnabled(false);
                        btnSave.setEnabled(true);
                        break;
            case "Update":
                        txtUsername.setEditable(true);
                        txtPassword.setEditable(true);
                        ddlUsertype.setEditable(true);
                        ddlUserstatus.setEditable(true);
                        txtName.setEditable(true);
                        txtContactnumber.setEditable(true);
                        txtEmail.setEditable(true); 
                        txtUserid.setEditable(false);
                        flag = "update";
                        btnAdd.setEnabled(false);
                        btnUpdate.setEnabled(false);
                        btnCancel.setEnabled(false);
                        btnSave.setEnabled(true);
                        break;
            case "Save":
                        switch(flag)
                        {
                            case "add":
                                    try
                                    {
                                        Connection con = DBConnection.getConnection();
                                        PreparedStatement stmt=con.prepareStatement("insert into usermaster(User_ID,Username,Password,User_Type,User_Status,Name,contact_Number,Email) values(?,?,?,?,?,?,?,?)");
                                        stmt.setInt(1, userid);
                                        stmt.setString(2, username);
                                        stmt.setString(3, pass);
                                        stmt.setString(4, utype);
                                        stmt.setString(5, ustatus);
                                        stmt.setString(6, name);
                                        stmt.setString(7, contact);
                                        stmt.setString(8, email);   
                                        stmt.executeUpdate();
                                        JOptionPane.showMessageDialog(rootPane, "Added successfully");
                                        con.close();
                                        getFirst();
                                        txtUsername.setEditable(false);
                                        txtPassword.setEditable(false);
                                        ddlUsertype.setEditable(false);
                                        ddlUserstatus.setEditable(false);
                                        txtName.setEditable(false);
                                        txtContactnumber.setEditable(false);
                                        txtEmail.setEditable(false);
                                        
                                        btnSave.setEnabled(false);
                                        btnAdd.setEnabled(true);
                                        btnUpdate.setEnabled(true);
                                        btnCancel.setEnabled(true);
                                        btnFirst.setEnabled(true);
                                        btnPrev.setEnabled(true);
                                        btnNext.setEnabled(true);
                                        btnLast.setEnabled(true);
                                    }
                                    catch(Exception ex)
                                    {
                                        JOptionPane.showMessageDialog(rootPane, "User Detail Save button : "+e);
                                    }    
                                    break;
                            case "update":
                                        try
                                        {
                                            Connection con = DBConnection.getConnection();
                                            PreparedStatement stmt=con.prepareStatement("Update usermaster set Username=?, Password=?, User_Status=?, User_Type=?, Name=?, Contact_Number=?, Email=? where  User_ID=?");
                                            stmt.setString(1, username);
                                            stmt.setString(2, pass);
                                            stmt.setString(3, ustatus);
                                            stmt.setString(4, utype);
                                            stmt.setString(5, name);
                                            stmt.setString(6, contact);
                                            stmt.setString(7, email);
                                            stmt.setInt(8, userid);
                                            stmt.executeUpdate();
                                            JOptionPane.showMessageDialog(rootPane, "Update successfully");
                                            con.close();
                                            getFirst();
                                            txtUsername.setEditable(false);
                                            txtPassword.setEditable(false);
                                            ddlUsertype.setEditable(false);
                                            ddlUserstatus.setEditable(false);
                                            txtName.setEditable(false);
                                            txtContactnumber.setEditable(false);
                                            txtEmail.setEditable(false);

                                            btnSave.setEnabled(false);
                                            btnAdd.setEnabled(true);
                                            btnUpdate.setEnabled(true);
                                            btnCancel.setEnabled(true);
                                            btnFirst.setEnabled(true);
                                            btnPrev.setEnabled(true);
                                            btnNext.setEnabled(true);
                                            btnLast.setEnabled(true);
                                        }
                                        catch(Exception ex)
                                        {
                                            JOptionPane.showMessageDialog(rootPane, "user detail update : "+e);
                                        }
                                        break;
                        }
                        break;
            case "Cancel":
                        this.dispose();
                        break;
            
        }
    }
}
