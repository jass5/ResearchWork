package CodeLevelSecurity;

import Beans.ProgramAccessedReportBean;
import Beans.ProgramUpdateReportBean;
import Beans.SavedProgramBean;
import CodeLevelSecurity.alpha.ApplicationIDE;
import CodeLevelSecurity.alpha.DBOperations;
import CodeLevelSecurity.encrypto.EncryptionManager;
import Threads.CompileThread;
import Threads.RunThread;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class NewIDE extends javax.swing.JFrame implements ActionListener{

    boolean isSavedFlag = false;
    String path = "";
    String filename = "";
    String idePath = "c:\\ide";
    String tempPath;
    JFileChooser fileChooser = null;
    File selectedfile = null;
    CompileThread CThread = null;
    RunThread Rthread = null;
    int openedProgramId = 0;
    int userId = 0;
    EncryptionManager encryptionManager = new EncryptionManager();
    public NewIDE() {
        initComponents();
        File f = new File(idePath);
        if (!f.exists()) {
            f.mkdirs();
        }
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        userId = codelevelsecurity.MainFrame.UserID;
        setBounds(13, 120, 1000, 600);
        pnlNotepad.setVisible(false);
        pnlOutput.setVisible(false);
        miCompile.setEnabled(true);
        miRun.setEnabled(true);
        miSave.setEnabled(true);
        miSaveAs.setEnabled(false);
        setVisible(true);
        this.miNew.addActionListener(this);
        this.miCompile.addActionListener(this);
        this.miExit.addActionListener(this);
        this.miOpen.addActionListener(this);
        this.miRun.addActionListener(this);
        this.miSave.addActionListener(this);
        this.miSaveAs.addActionListener(this);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlNotepad = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtNotepad = new javax.swing.JTextArea();
        pnlOutput = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();
        mbIDE = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        miNew = new javax.swing.JMenuItem();
        miOpen = new javax.swing.JMenuItem();
        miSave = new javax.swing.JMenuItem();
        miSaveAs = new javax.swing.JMenuItem();
        miExit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        miCompile = new javax.swing.JMenuItem();
        miRun = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNotepad.setColumns(20);
        txtNotepad.setRows(5);
        jScrollPane2.setViewportView(txtNotepad);

        javax.swing.GroupLayout pnlNotepadLayout = new javax.swing.GroupLayout(pnlNotepad);
        pnlNotepad.setLayout(pnlNotepadLayout);
        pnlNotepadLayout.setHorizontalGroup(
            pnlNotepadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 731, Short.MAX_VALUE)
        );
        pnlNotepadLayout.setVerticalGroup(
            pnlNotepadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );

        getContentPane().add(pnlNotepad, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        txtOutput.setColumns(20);
        txtOutput.setRows(5);
        jScrollPane1.setViewportView(txtOutput);

        javax.swing.GroupLayout pnlOutputLayout = new javax.swing.GroupLayout(pnlOutput);
        pnlOutput.setLayout(pnlOutputLayout);
        pnlOutputLayout.setHorizontalGroup(
            pnlOutputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 731, Short.MAX_VALUE)
        );
        pnlOutputLayout.setVerticalGroup(
            pnlOutputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
        );

        getContentPane().add(pnlOutput, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        jMenu1.setText("File");

        miNew.setText("New");
        jMenu1.add(miNew);

        miOpen.setText("Open");
        jMenu1.add(miOpen);

        miSave.setText("Save");
        jMenu1.add(miSave);

        miSaveAs.setText("SaveAs");
        jMenu1.add(miSaveAs);

        miExit.setText("Exit");
        jMenu1.add(miExit);

        mbIDE.add(jMenu1);

        jMenu2.setText("Execute");

        miCompile.setText("Compile");
        jMenu2.add(miCompile);

        miRun.setText("Run");
        jMenu2.add(miRun);

        mbIDE.add(jMenu2);

        setJMenuBar(mbIDE);

        setSize(new java.awt.Dimension(749, 500));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewIDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewIDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewIDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewIDE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewIDE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JMenuBar mbIDE;
    private javax.swing.JMenuItem miCompile;
    private javax.swing.JMenuItem miExit;
    private javax.swing.JMenuItem miNew;
    private javax.swing.JMenuItem miOpen;
    private javax.swing.JMenuItem miRun;
    private javax.swing.JMenuItem miSave;
    private javax.swing.JMenuItem miSaveAs;
    private javax.swing.JPanel pnlNotepad;
    private javax.swing.JPanel pnlOutput;
    private javax.swing.JTextArea txtNotepad;
    private javax.swing.JTextArea txtOutput;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        String btnClicked = e.getActionCommand();
        DBOperations objDBOperations;
        ProgramUpdateReportBean pobjBean;
        SavedProgramBean sobjBean;
        switch(btnClicked)
        {
            case "New":
                    if (txtNotepad.getText().equals("")) 
                    {
                        pnlNotepad.setVisible(true);
                        pnlOutput.setVisible(false);
                        miSave.setEnabled(true);
                        miSaveAs.setEnabled(true);
                    } 
                    else 
                    {
                        int option = JOptionPane.showConfirmDialog(miCompile, miSave);
                        if (option == 0) 
                        {
                            //save
                            fileChooser = new JFileChooser();
                            fileChooser.showSaveDialog(this);

                            selectedfile = null;

                            selectedfile = fileChooser.getSelectedFile();
                            path = selectedfile.getPath();

                            String content = txtNotepad.getText();
                            ApplicationIDE.saveFile(path, content);

                            path = "";
                            fileChooser = null;
                            selectedfile = null;

                            txtNotepad.setText("");
                            pnlNotepad.setVisible(true);
                            pnlOutput.setVisible(false);

                        } 
                        else if (option == 1) 
                        {
                            //not save
                            path = "";
                            selectedfile = null;
                            fileChooser = null;
                            txtNotepad.setText("");
                            pnlNotepad.setVisible(true);
                            pnlOutput.setVisible(false);
                        } else {
                            //cancel
                            txtNotepad.setText("");
                        }
                    }
                    break;
            case "Open":
                    pnlNotepad.setVisible(true);
                    miSaveAs.setEnabled(true);
                    fileChooser = new JFileChooser();
                    fileChooser.showOpenDialog(this);
                    selectedfile = fileChooser.getSelectedFile();
                    path = selectedfile.getPath();
                    filename = selectedfile.getName();

                    encryptionManager.decryptSource(path, idePath + "\\" + filename);
                    txtNotepad.setText(ApplicationIDE.getFileContent(idePath + "\\" + filename));

                    objDBOperations = new DBOperations();

                    openedProgramId = objDBOperations.getOpenedProgramId(path, userId);

                    ProgramAccessedReportBean objBean = new ProgramAccessedReportBean();
                    objBean.setProgram_ID(openedProgramId);

                    // objBean.setProgram_Path(path);           
                    objBean.setViewer_User_ID(codelevelsecurity.MainFrame.UserID);
                    objDBOperations.AccessProgram(objBean);
                    break;
            case "Save":
                    if (!txtNotepad.getText().equals("")) 
                    {
                        boolean saveData = true;
                        if (path.equals("")) 
                        {
                            fileChooser = new JFileChooser();
                            fileChooser.showSaveDialog(this);

                            selectedfile = fileChooser.getSelectedFile();
                            path = selectedfile.getPath();
                            filename = selectedfile.getName();

                            selectedfile = null;
                            fileChooser = null;
                            isSavedFlag = true;
                        }
                        if (saveData == true) 
                        {
                            String content = txtNotepad.getText();
                            ApplicationIDE.saveFile(idePath + File.separator + filename, content);
                        }
                        objDBOperations = new DBOperations();
                        encryptionManager.encryptSource(idePath + File.separator + filename, path);
                        if (isSavedFlag == false) 
                        {
                            openedProgramId = objDBOperations.getOpenedProgramId(path, userId);
                            pobjBean = new ProgramUpdateReportBean();
                            pobjBean.setProgram_ID(openedProgramId);
                            pobjBean.setUser_ID(codelevelsecurity.MainFrame.UserID);
                            objDBOperations.UpdateProgram(pobjBean);
                        } 
                        else 
                        {
                            sobjBean = new SavedProgramBean();
                            sobjBean.setProgram_Name(filename);
                            sobjBean.setProgram_Path(path);
                            sobjBean.setUser_ID(codelevelsecurity.MainFrame.UserID);
                            objDBOperations.AddNewProgram(sobjBean);
                        }
                    }
                    break;
            case "SaveAs":
                    fileChooser = new JFileChooser();
                    fileChooser.showSaveDialog(this);
                    filename = fileChooser.getSelectedFile().getName();
                    path = fileChooser.getSelectedFile().getAbsolutePath();
                    selectedfile = fileChooser.getSelectedFile();
                    String selectedPath = selectedfile.getPath();

                    String content = txtNotepad.getText();
                    ApplicationIDE.saveFile(selectedPath, content);

                    selectedfile = null;
                    fileChooser = null;

                    objDBOperations = new DBOperations();
                    sobjBean = new SavedProgramBean();
                    sobjBean.setProgram_Name(filename);
                    sobjBean.setProgram_Path(path);
                    sobjBean.setUser_ID(codelevelsecurity.MainFrame.UserID);
                    objDBOperations.AddNewProgram(sobjBean);
                    break;
            case "Exit":
                    this.dispose();
                    File f[] = new File(idePath).listFiles();
                    for (int i = 0; i < f.length; i++) {
                        try 
                        {
                            f[i].delete();
                        } 
                        catch (Exception ex) 
                        {
                            continue;
                        }
                    }
                    break;
            case "Compile":
                    pnlNotepad.setVisible(true);
                    pnlOutput.setVisible(true);
                    txtOutput.setText("");
                    //mnuCompile.setEnabled(true);
                    //mnuCompile.setVisible(true);
                    try {

                        String subPath = path.substring(0, path.lastIndexOf("\\"));
                        String fileName = path.substring(path.lastIndexOf("\\") + 1, path.length());
                        //String path1 = "E:\\javademo";
                        System.out.println(subPath);
                        String command = "javac -cp " + idePath + " " + idePath + File.separator + filename;
                        System.out.println(command);
                        Runtime rt = Runtime.getRuntime();
                        Process p = rt.exec(command);
                        InputStream is = p.getErrorStream();

                        BufferedReader br = new BufferedReader(new InputStreamReader(is));

                        String line = "";
                        String result = "";

                        while ((line = br.readLine()) != null) {
                            result = result + line;
                            txtOutput.setText(result);
                        }
                        if (result.equals("")) {
                            txtOutput.setText("COMPILED");
                        } else {
                            System.out.println("error" + result);
                            if (!result.equals("")) {
                            }
                        }
                    } catch (Exception ex) {
                        System.out.println("" + ex);
                    }
                    break;
            case "Run":
                    pnlNotepad.setVisible(true);
                    pnlOutput.setVisible(true);

                    try {
                        String subPath = path.substring(0, path.lastIndexOf("\\"));
                        String fileName = path.substring(path.lastIndexOf("\\") + 1, path.length());

                        String command = "java -classpath " + idePath + " " + filename.substring(0, fileName.lastIndexOf("."));
                        Runtime rt = Runtime.getRuntime();
                        Process p = rt.exec(command);

                        InputStream is = p.getInputStream();
                        InputStream isa = p.getErrorStream();

                        BufferedReader br = new BufferedReader(new InputStreamReader(is));
                        BufferedReader brc = new BufferedReader(new InputStreamReader(isa));

                        String line = "";
                        String result = "";

                        while ((line = brc.readLine()) != null) {
                            result = result + line;
                            //txtOutput.setText(result);
                        }
                        System.out.println("aa" + result);
                        if (result.equals("")) {
                            while ((line = br.readLine()) != null) {
                                result = result + line;
                                txtOutput.setText(result);
                            }
                            System.out.println("successful run  : " + result);
                            txtOutput.setText(result);
                            //System.out.println("OUTPUT  :  " + result);
                        } else {
                            System.out.println("ERROR  :  " + result);
                        }

                    } catch (Exception ex) {
                        System.out.println("in run method" + ex);
                    }
                    break;
            
                    
        }
    }
}
