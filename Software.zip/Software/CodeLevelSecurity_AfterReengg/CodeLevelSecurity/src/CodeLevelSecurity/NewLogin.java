package CodeLevelSecurity;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import CodeLevelSecurity.alpha.DBConnection;
import java.sql.PreparedStatement;


public class NewLogin extends javax.swing.JFrame implements ActionListener{

    public NewLogin() {
        initComponents();
        this.btnlogin.addActionListener(this);
        this.btncancel.addActionListener(this);
        this.btnretrieve.addActionListener(this);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtpassword = new javax.swing.JPasswordField();
        txtuname = new javax.swing.JTextField();
        btncancel = new javax.swing.JButton();
        btnretrieve = new javax.swing.JButton();
        btnlogin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("UserName");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, -1, -1));

        jLabel2.setText("Password");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, -1, -1));
        getContentPane().add(txtpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 180, -1));
        getContentPane().add(txtuname, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 50, 180, -1));

        btncancel.setText("Cancel");
        getContentPane().add(btncancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, -1, -1));

        btnretrieve.setText("Retrieve Password");
        getContentPane().add(btnretrieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, -1, -1));

        btnlogin.setText("Login");
        getContentPane().add(btnlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, -1, -1));

        setSize(new java.awt.Dimension(406, 279));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncancel;
    private javax.swing.JButton btnlogin;
    private javax.swing.JButton btnretrieve;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField txtpassword;
    private javax.swing.JTextField txtuname;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        if(txtuname.getText().equals("") || txtpassword.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "Fields can't be empty!");
        }
        else
        {
            String btnClicked = e.getActionCommand();
            switch(btnClicked)
            {
                case "Login":
                        try
                        {
                            Connection con = DBConnection.getConnection();
                            PreparedStatement stmt = con.prepareStatement("select * from usermaster where username=? and password=?");
                            stmt.setString(1,txtuname.getText());
                            stmt.setString(2,txtpassword.getText());
                            ResultSet rs = stmt.executeQuery();
                            if(rs.next())
                            {
                                codelevelsecurity.MainFrame obj = new codelevelsecurity.MainFrame();
                                this.dispose();
                                obj.setVisible(true);
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(rootPane, "Wrong UserName or Password");
                            }
                        }
                        catch(java.sql.SQLException ex)
                        {
                            JOptionPane.showMessageDialog(rootPane, "ActionPerformed(Login) : "+ex);
                        }
                        break;
                case "Cancel":
                        this.dispose();
                        break;
                case "Retrieve Password":
                        
                        break;
            }
        }
    }
}
