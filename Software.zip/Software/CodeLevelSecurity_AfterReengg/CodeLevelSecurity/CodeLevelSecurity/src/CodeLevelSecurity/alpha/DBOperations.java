/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
package CodeLevelSecurity.alpha;

import Beans.ProgramAccessedReportBean;
import Beans.ProgramReportBean;
import Beans.ProgramUpdateReportBean;
import Beans.SavedProgramBean;
import Beans.UsermasterBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author student
 */
public class DBOperations {

    public UsermasterBean authenticateUser(String Username, String Password) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        UsermasterBean objBean = null;
        try {
            con = DBConnection.getConnection();
            pstmt = con.prepareStatement("select * from usermaster where username=?");
            pstmt.setString(1, Username);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                if (rs.getString("Password").equals(Password)) {
                    objBean = new UsermasterBean();
                    objBean.setUser_ID(rs.getInt("User_ID"));
                    objBean.setUsername(rs.getString("Username"));
                    objBean.setPassword(rs.getString("Password"));

                    objBean.setUser_Type(rs.getString("User_Type"));
                    objBean.setUser_Status(rs.getString("User_Status"));
                    objBean.setName(rs.getString("Name"));
                    objBean.setContact_Number(rs.getString("Contact_Number"));
                    objBean.setEmail(rs.getString("Email"));
                }
            }
        } catch (Exception e) {
            System.out.println("authenticateUser(String userName, String password) : of DBoperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();


            } catch (Exception e) {
                System.out.println("authenticateUser(String userName, String password) : of DBoperations" + e);
            }
        }

        return objBean;
    }

    public ArrayList getAllUserDetailList() {
        Connection conn = null;
        ArrayList alstUser = new ArrayList();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("select User_ID,Username,Password,User_Type,User_Status,Name,Contact_Number,Email from usermaster");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                {
                    UsermasterBean objBean = new UsermasterBean();
                    objBean.setUser_ID(rs.getInt("User_ID"));
                    objBean.setUsername(rs.getString("Username"));
                    objBean.setPassword(rs.getString("Password"));
                    objBean.setUser_Type(rs.getString("User_Type"));
                    objBean.setUser_Status(rs.getString("User_Status"));
                    objBean.setName(rs.getString("Name"));
                    objBean.setContact_Number(rs.getString("Contact_Number"));
                    objBean.setEmail(rs.getString("Email"));
                    alstUser.add(objBean);

                }
            }
        } catch (Exception e) {
            System.out.println("getAllUserDetailList of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("getAllUserDetailList of DBopertaions");
            }
        }
        return alstUser;
    }

    public ArrayList getAllUsernames() {
        Connection conn = null;
        ArrayList alstUser = new ArrayList();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("select Username from usermaster");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                {
                    UsermasterBean objBean = new UsermasterBean();

                    objBean.setUsername(rs.getString("Username"));

                    alstUser.add(objBean);

                }
            }
        } catch (Exception e) {
            System.out.println("getAllUsernames of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("getAllUsernames of DBopertaions");
            }
        }
        return alstUser;
    }

    public int getMaxUserID() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int maxUserID = 0;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select max(User_ID) from usermaster");
            rs = pstmt.executeQuery();

            if (rs.next()) {
                maxUserID = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxUserID of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("GetMaxUserID of DBOperations" + e);
            }
        }
        return maxUserID;
    }

    public String addUserAccountDetail(UsermasterBean objBean) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String result = "failed";
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from usermaster where username=?");
            pstmt.setString(1, objBean.getUsername());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                result = "exists";
            } else {
                pstmt = conn.prepareStatement("Insert into usermaster(User_ID,Username,Password,User_Type,User_Status,Name,contact_Number,Email)values(?,?,?,?,?,?,?,?)");
                pstmt.setInt(1, objBean.getUser_ID());
                pstmt.setString(2, objBean.getUsername());
                pstmt.setString(3, objBean.getPassword());
                pstmt.setString(4, objBean.getUser_Type());
                pstmt.setString(5, objBean.getUser_Status());
                pstmt.setString(6, objBean.getName());
                pstmt.setString(7, objBean.getContact_Number());
                pstmt.setString(8, objBean.getEmail());

                System.out.println(pstmt.toString());
                int i = pstmt.executeUpdate();
                if (i > 0) {
                    result = "added";
                }



            }
        } catch (Exception e) {
            System.out.println("AddUserAccountDetail of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("AddUserAccountDetail of DBOperations" + e);
            }
        }
        return result;
    }

    public String updateUserAccountDetail(UsermasterBean objBean) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String result = "failed";
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from usermaster where username=? and user_id!=?");
            pstmt.setString(1, objBean.getUsername());
            pstmt.setInt(2, objBean.getUser_ID());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                result = "exists";
            } else {
                pstmt = conn.prepareStatement("Update usermaster set Username=?, Password=?, User_Status=?, User_Type=?, Name=?, Contact_Number=?, Email=? where  User_ID=?");
                pstmt.setString(1, objBean.getUsername());
                pstmt.setString(2, objBean.getPassword());
                pstmt.setString(3, objBean.getUser_Status());
                pstmt.setString(4, objBean.getUser_Type());
                pstmt.setString(5, objBean.getName());
                pstmt.setString(6, objBean.getContact_Number());
                pstmt.setString(7, objBean.getEmail());
                pstmt.setInt(8, objBean.getUser_ID());

                System.out.println(pstmt.toString());
                int i = pstmt.executeUpdate();
                if (i > 0) {
                    result = "updated";
                }
            }
        } catch (Exception e) {
            System.out.println("UpdateUserAccountDetail of DBOperations" + e);
        }
        try {
            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("UpdateUserAccountDetail of DBOperations" + e);
        }
        return result;
    }

    public String updateProfileDetail(UsermasterBean objBean) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String result = "failed";
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from usermaster where username=? and user_id!=?");
            pstmt.setString(1, objBean.getUsername());
            pstmt.setInt(2, objBean.getUser_ID());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                result = "exists";
            } else {
                pstmt = conn.prepareStatement("Update usermaster set Username=?, Password=?, Name=?, Contact_Number=?, Email=? where  User_ID=?");
                pstmt.setString(1, objBean.getUsername());
                pstmt.setString(2, objBean.getPassword());

                pstmt.setString(3, objBean.getName());
                pstmt.setString(4, objBean.getContact_Number());
                pstmt.setString(5, objBean.getEmail());
                pstmt.setInt(6, objBean.getUser_ID());
                System.out.println(pstmt.toString());
                int i = pstmt.executeUpdate();
                System.out.println(pstmt.toString());
                if (i > 0) {
                    result = "updated";
                }
            }
        } catch (Exception e) {
            System.out.println("UpdateProfileDetail of DBOperations" + e);
        }
        try {
            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("UpdateUserProfileDetail of DBOperations" + e);
        }
        return result;
    }

    public ArrayList getAllSavedReports() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        SavedProgramBean objBean = null;
        ArrayList alst = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from programmaster");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setCreate_Date(rs.getString("Cretae_Date"));
                objBean.setProgram_Path(rs.getString("Program_Path"));
                alst.add(objBean);
            }

        } catch (Exception e) {
            System.out.println("Exception in getAllSavedReports" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in getAllSavedReports" + e);
            }
        }
        return alst;
    }

    public int getMaxProgramID() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int maxProgramID = 0;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select max(Program_ID) from programmaster");
            rs = pstmt.executeQuery();

            if (rs.next()) {
                maxProgramID = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxProgramID of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("GetMaxProgramID of DBOperations" + e);
            }
        }
        return maxProgramID;
    }

    public String AddNewProgram(SavedProgramBean objBean) {

        DBOperations objDB = new DBOperations();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String result = "failed";
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new java.util.Date());
            conn = DBConnection.getConnection();
            /*pstmt = conn.prepareStatement("Select * from programmaster where Program_ID=?");
            pstmt.setInt(1, objBean.getProgram_ID());
            rs = pstmt.executeQuery();
            if (rs.next()) {
            result = "exists";
            } else {*/
            pstmt = conn.prepareStatement("Insert into programmaster (User_ID,Program_ID,Program_Name,Create_Date,Program_Path) values(?,?,?,?,?)");
            pstmt.setInt(1, objBean.getUser_ID());
            pstmt.setInt(2, objDB.getMaxProgramID() + 1);
            pstmt.setString(3, objBean.getProgram_Name());
            pstmt.setString(4, date);
            pstmt.setString(5, objBean.getProgram_Path());
            int i = pstmt.executeUpdate();
            if (i > 0) {
                result = "added";
            }

        } catch (Exception e) {
            System.out.println("Exception in AddNewProgram" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in AddNewProgram" + e);
            }

            return result;
        }

    }

    public ArrayList ProgramAccessedreport() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ProgramAccessedReportBean objBean = null;
        ArrayList alstuser = new ArrayList();

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select p.Program_ID,p.Program_Name,p.User_ID as Owner_User_ID,p.Create_Date,q.User_ID as Viewer_User_ID,q.Access_Date from programmaster as p,programaccessmaster as q where p.Program_ID=q.Program_ID");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean = new ProgramAccessedReportBean();
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setOwner_User_ID(rs.getInt("Owner_User_ID"));
                objBean.setViewer_User_ID(rs.getInt("Viewer_User_ID"));
                objBean.setCreate_Date(rs.getString("Create_Date"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setAccess_Date(rs.getString("Access_Date"));
                alstuser.add(objBean);
            }

        } catch (Exception e) {
            System.out.println("Exception" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in getAllSavedReports" + e);
            }
        }
        return alstuser;
    }

    public ArrayList ProgramReport() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ProgramReportBean objBean = null;
        ArrayList alstUser = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select p.Program_ID,p.User_ID,p.Program_Name,p.Create_Date,p.Program_Path,u.User_ID,u.Username from programmaster as p,usermaster as u where p.User_ID=u.User_ID");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean = new ProgramReportBean();
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setUsername(rs.getString("Username"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setProgram_Path(rs.getString("Program_Path"));
                objBean.setCreate_Date(rs.getString("Create_Date"));

                alstUser.add(objBean);
            }
        } catch (Exception e) {
            System.out.println("Exception in User" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in getAllSavedReports" + e);
            }
        }
        return alstUser;
    }

    public ArrayList SavedProgramReport() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        SavedProgramBean objBean = null;
        ArrayList alstUser = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from programmaster");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean = new SavedProgramBean();
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setCreate_Date(rs.getString("Create_Date"));
                objBean.setProgram_Path(rs.getString("Program_Path"));
                alstUser.add(objBean);
            }
        } catch (Exception e) {
            System.out.println("Exception in SavedProgramReport" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in SavedProgramReports" + e);
            }
        }
        return alstUser;
    }

    public ArrayList ProgramUpdateReport() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ProgramUpdateReportBean objBean = null;
        ArrayList alstUser = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select p.Program_Name,p.User_ID,p.Program_Name,p.Create_Date,u.Program_ID,u.Update_Date from programmaster as p,programupdatemaster as u where p.Program_ID=u.Program_ID");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean = new ProgramUpdateReportBean();
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setCreate_Date(rs.getString("Create_Date"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setUpdate_Date(rs.getString("Update_Date"));
                alstUser.add(objBean);
            }
        } catch (Exception e) {
            System.out.println("Exception in User" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in getAllSavedReports" + e);
            }
        }
        return alstUser;
    }

    public int getMaxProgramUpdateID() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int maxProgramUpdateID = 0;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select max(Program_Update_ID) from programaUpdatemaster");
            rs = pstmt.executeQuery();

            if (rs.next()) {
                maxProgramUpdateID = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxProgramUpdateID of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("GetMaxProgramUpdateID of DBOperations" + e);
            }
        }
        return maxProgramUpdateID;
    }

    public String AccessProgram(ProgramAccessedReportBean objBean) {

        DBOperations objDB = new DBOperations();

        Connection conn = null;
        PreparedStatement pstmt = null;

        String result = "failed";
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new java.util.Date());
            conn = DBConnection.getConnection();

            pstmt = conn.prepareStatement("Insert into programaccessmaster (Program_ID,User_ID,Access_Date) values(?,?,sysdate())");

            pstmt.setInt(1, objBean.getProgram_ID());
            pstmt.setInt(2, objBean.getViewer_User_ID());
            System.out.println("" + pstmt);

            int i = pstmt.executeUpdate();
            if (i > 0) {
                result = "Accessed";
            }

        } catch (Exception e) {
            System.out.println("Exception in AccessProgram" + e);
        } finally {
            try {

                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in AccessProgram" + e);
            }

            return result;
        }

    }

    public int getMaxProgramAccessID() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int maxProgramAccessID = 0;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select max(Program_Access_ID) from programaccessmaster");
            rs = pstmt.executeQuery();

            if (rs.next()) {
                maxProgramAccessID = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxProgramaccessID of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("GetMaxProgramaccessID of DBOperations" + e);
            }
        }
        return maxProgramAccessID;
    }

    public int getOpenedProgramId(String path, int userid) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int programID = 0;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select Program_Id from programmaster where Program_Path=? and User_Id=?");
            pstmt.setString(1, path);
            pstmt.setInt(2, userid);
            System.out.println("open   " + pstmt);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                programID = rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxProgramaccessID of DBOperations" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("GetMaxProgramaccessID of DBOperations" + e);
            }
        }
        return programID;
    }

    public String UpdateProgram(ProgramUpdateReportBean objBean) {

        DBOperations objDB = new DBOperations();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String result = "failed";
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new java.util.Date());
            conn = DBConnection.getConnection();

            pstmt = conn.prepareStatement("Insert into programupdatemaster (Program_ID,Update_Date) values(?,sysdate())");

            pstmt.setInt(1, objBean.getProgram_ID());


            int i = pstmt.executeUpdate();
            if (i > 0) {
                result = "updated";

            }
        } catch (Exception e) {
            System.out.println("Exception in UpdateProgram" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in UpdateProgram" + e);
            }

            return result;
        }
    }

    public ArrayList ProgramUpdateReportByUsername(String Username) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ProgramUpdateReportBean objBean = null;
        ArrayList alstUser = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select p.Program_ID,p.Program_Name,p.User_ID,p.Program_Name,p.Create_Date,u.Program_ID,u.Update_Date from programmaster as p,programupdatemaster as u,usermaster where p.Program_ID=u.Program_ID and p.User_ID=usermaster.User_ID and usermaster.username like ?");
            pstmt.setString(1, "%" + Username + "%");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean = new ProgramUpdateReportBean();
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setCreate_Date(rs.getString("Create_Date"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setUpdate_Date(rs.getString("Update_Date"));
                alstUser.add(objBean);
            }
        } catch (Exception e) {
            System.out.println("Exception in User" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in getAllSavedReports" + e);
            }
        }
        return alstUser;
    }

    public UsermasterBean getUserDetailByUsername(String Username) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        UsermasterBean objBean = null;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select * from usermaster where Username=?");
            pstmt.setString(1, Username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                objBean = new UsermasterBean();
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setUsername(rs.getString("Username"));
                objBean.setPassword(rs.getString("Password"));
                objBean.setUser_Type(rs.getString("User_Type"));
                objBean.setUser_Status(rs.getString("User_Status"));
                objBean.setEmail(rs.getString("Email"));
                objBean.setName(rs.getString("Name"));
                objBean.setContact_Number(rs.getString("Contact_Number"));

            }
        } catch (Exception e) {
            System.out.println("getUserDetailByUsername(String userName) of DBOperations :" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("getUserDetailByUsername(String userName) of DBOperations :" + e);
            }
        }
        return objBean;
    }

    public ArrayList SavedReports(String Username) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        SavedProgramBean objBean = null;
        ArrayList alst = new ArrayList();
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("Select p.Program_ID,p.User_ID,p.Program_Name,p.Create_Date,p.Program_Path from programmaster as p,usermaster where p.User_ID=usermaster.User_ID and usermaster.username like ?");
            pstmt.setString(1, "%" + Username + "%");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                objBean.setProgram_ID(rs.getInt("Program_ID"));
                objBean.setUser_ID(rs.getInt("User_ID"));
                objBean.setProgram_Name(rs.getString("Program_Name"));
                objBean.setCreate_Date(rs.getString("Cretae_Date"));
                objBean.setProgram_Path(rs.getString("Program_Path"));
                alst.add(objBean);
            }

        } catch (Exception e) {
            System.out.println("Exception in SavedReports" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                System.out.println("Exception in SavedReports" + e);
            }
        }
        return alst;
    }
}
