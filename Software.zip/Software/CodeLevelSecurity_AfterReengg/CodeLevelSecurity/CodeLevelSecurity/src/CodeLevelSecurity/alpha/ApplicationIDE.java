/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CodeLevelSecurity.alpha;

import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author Paramjeet Kaur
 */
public class ApplicationIDE {
public static void saveFile(String path,String content){
    FileWriter fw=null;
    try{
        fw= new FileWriter(path);
        fw.write(content);
    }catch(Exception e){
        System.out.println(e);
    }finally{
        try{
            fw.close();
            
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
}    
public static String getFileContent(String path){
    StringBuffer content=new StringBuffer("");
    
    FileReader fr=null;
    try{
        int ch=0;
        fr=new FileReader(path);
        while((ch=fr.read())!= -1){
            content.append(String.valueOf((char)ch));
            
        }
    }catch(Exception e){
        System.out.println(e);
    }finally{
        try{
            fr.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    return content.toString();
} 
}
