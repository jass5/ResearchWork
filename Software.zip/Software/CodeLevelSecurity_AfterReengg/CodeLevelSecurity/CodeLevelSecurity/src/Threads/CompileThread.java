/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Threads;

import codelevelsecurity.IDE;

/**
 *
 * @author student
 */
    public class CompileThread extends Thread {
        StringBuffer compileErrors= new StringBuffer();
        IDE ide= null;
        public CompileThread(IDE ide)
        {
            
        }
    }
    

