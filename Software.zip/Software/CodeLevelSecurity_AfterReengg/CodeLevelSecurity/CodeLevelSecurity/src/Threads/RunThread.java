/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Threads;

import codelevelsecurity.IDE;

/**
 *
 * @author student
 */
public class RunThread extends Thread{
    StringBuffer runErrors = new StringBuffer();
    IDE ide=null;
    public RunThread (IDE ide)
    {
        this.ide=ide;
    }
}

