/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CodeLevelSecurity_Reports;

import CodeLevelSecurity.alpha.DBConnection;

import java.io.InputStream;
import java.sql.Connection;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Paramjeet Kaur
 */
public class JasperReportGenerator {
        InputStream designFileStream;
    
    public JasperReportGenerator(InputStream designFileStream){
        this.designFileStream=designFileStream;
        generateReport();
    }
    
    void generateReport(){
        try{
            JasperDesign jasperDesign=JRXmlLoader.load(designFileStream);
            JasperReport jasperReport=JasperCompileManager.compileReport(jasperDesign);
            Connection conn=DBConnection.getConnection();
            JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, null,conn);
            JasperViewer.viewReport(jasperPrint,false);
                    
           
        }catch(Exception e){
            System.out.println("Exception in generating report,generatereport() of jasperReportGenerator :"+e);
        }
    }

}
