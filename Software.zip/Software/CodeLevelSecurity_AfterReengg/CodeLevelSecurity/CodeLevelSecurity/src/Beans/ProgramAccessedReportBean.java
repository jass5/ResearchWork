/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author student
 */
public class ProgramAccessedReportBean {
    private int Program_ID;
    private int Owner_User_ID;
    private int Viewer_User_ID;
    private String Program_Name;
    private String Create_Date;
    private String Access_Date;

    public String getAccess_Date() {
        return Access_Date;
    }

    public void setAccess_Date(String Access_Date) {
        this.Access_Date = Access_Date;
    }

    public String getCreate_Date() {
        return Create_Date;
    }

    public void setCreate_Date(String Create_Date) {
        this.Create_Date = Create_Date;
    }

    public int getOwner_User_ID() {
        return Owner_User_ID;
    }

    public void setOwner_User_ID(int Owner_User_ID) {
        this.Owner_User_ID = Owner_User_ID;
    }

    public int getProgram_ID() {
        return Program_ID;
    }

    public void setProgram_ID(int Program_ID) {
        this.Program_ID = Program_ID;
    }

    public String getProgram_Name() {
        return Program_Name;
    }

    public void setProgram_Name(String Program_Name) {
        this.Program_Name = Program_Name;
    }

    public int getViewer_User_ID() {
        return Viewer_User_ID;
    }

    public void setViewer_User_ID(int Viewer_User_ID) {
        this.Viewer_User_ID = Viewer_User_ID;
    }
    
}
