/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author student
 */
public class UsermasterBean {
    private int User_ID;
    private String Username;
    private String Password;
    private String User_Type;
    private String User_Status;
    private String Name;
    private String Contact_Number;
    private String Email;

    public String getContact_Number() {
        return Contact_Number;
    }

    public void setContact_Number(String Contact_Number) {
        this.Contact_Number = Contact_Number;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getUser_ID() {
        return User_ID;
    }

    public void setUser_ID(int User_ID) {
        this.User_ID = User_ID;
    }

    public String getUser_Status() {
        return User_Status;
    }

    public void setUser_Status(String User_Status) {
        this.User_Status = User_Status;
    }

    public String getUser_Type() {
        return User_Type;
    }

    public void setUser_Type(String User_Type) {
        this.User_Type = User_Type;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }
    
        
}
